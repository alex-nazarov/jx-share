#!/bin/bash
#
# Diameter binary file parser.
# Reads a file containing raw Diameter packets, parses each packet and writes
# a human-readable representation to an output file using DiameterMessageLogger.
#
# Usage:
#   dm-file-parser.sh -i <input-file> [-o <output-file>] [-d <dictionary-xml>]
#
# If -o is omitted, output is written to <input-basename>.log next to this script.
# If -d is omitted, ../etc/avp-dictionary/dictionary.xml relative to this script
# is used. All jars from ../lib are added to the classpath and the main class
# com.jnetx.app.dm.fileparser.DiameterFileParser is executed.
#

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/../lib"
DEFAULT_DICTIONARY="${SCRIPT_DIR}/../etc/avp-dictionary/dictionary.xml"

usage() {
    echo "Usage: $(basename "$0") -i <input-file> [-o <output-file>] [-d <dictionary-xml>]"
    echo ""
    echo "  -i  Path to binary input file with Diameter packets (mandatory)"
    echo "  -o  Path to output text file (optional, defaults to <input-basename>.log next to this script)"
    echo "  -d  Path to dictionary XML (optional, defaults to ${DEFAULT_DICTIONARY})"
    exit 1
}

to_abs() {
    local path="$1"
    local dir name
    dir="$(cd "$(dirname -- "${path}")" && pwd)" || return 1
    name="$(basename -- "${path}")"
    printf '%s/%s\n' "${dir}" "${name}"
}

INPUT_FILE=""
OUTPUT_FILE=""
DICTIONARY=""

while getopts "i:o:d:h" opt; do
    case ${opt} in
        i) INPUT_FILE="${OPTARG}" ;;
        o) OUTPUT_FILE="${OPTARG}" ;;
        d) DICTIONARY="${OPTARG}" ;;
        h) usage ;;
        *) usage ;;
    esac
done

if [ -z "${INPUT_FILE}" ]; then
    echo "ERROR: Input file is mandatory."
    usage
fi

if [ ! -f "${INPUT_FILE}" ]; then
    echo "ERROR: Input file '${INPUT_FILE}' does not exist."
    exit 2
fi

INPUT_FILE="$(to_abs "${INPUT_FILE}")" || {
    echo "ERROR: Cannot resolve input path."
    exit 2
}

if [ -z "${OUTPUT_FILE}" ]; then
    INPUT_BASENAME="$(basename "${INPUT_FILE}")"
    INPUT_NAME="${INPUT_BASENAME%.*}"
    OUTPUT_FILE="${SCRIPT_DIR}/${INPUT_NAME}.log"
else
    if [ ! -d "$(dirname -- "${OUTPUT_FILE}")" ]; then
        echo "ERROR: Output directory '$(dirname -- "${OUTPUT_FILE}")' does not exist."
        exit 2
    fi
    OUTPUT_FILE="$(to_abs "${OUTPUT_FILE}")" || {
        echo "ERROR: Cannot resolve output path."
        exit 2
    }
fi

if [ ! -d "${LIB_DIR}" ]; then
    echo "ERROR: Library directory '${LIB_DIR}' not found."
    exit 3
fi

if [ -z "${DICTIONARY}" ]; then
    DICTIONARY="${DEFAULT_DICTIONARY}"
fi

if [ ! -f "${DICTIONARY}" ]; then
    echo "ERROR: Dictionary file '${DICTIONARY}' does not exist."
    exit 4
fi

DICTIONARY="$(to_abs "${DICTIONARY}")" || {
    echo "ERROR: Cannot resolve dictionary path."
    exit 4
}

CLASSPATH="${LIB_DIR}/*"

JAVA_ARGS=("${INPUT_FILE}" "${OUTPUT_FILE}" "${DICTIONARY}")

java -cp "${CLASSPATH}" com.jnetx.app.dm.fileparser.DiameterFileParser "${JAVA_ARGS[@]}"
EXIT_CODE=$?

if [ ${EXIT_CODE} -eq 0 ]; then
    echo "Dictionary: ${DICTIONARY}"
    echo "Output written to: ${OUTPUT_FILE}"
fi

exit ${EXIT_CODE}
